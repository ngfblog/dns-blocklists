# Title: HaGeZi's LG webOS Tracker DNS Blocklist
# Description: Blocks LG webOS native broadband tracker that track your activity.
# Homepage: https://github.com/hagezi/dns-blocklists
# Issues: https://github.com/hagezi/dns-blocklists/issues
# License: https://github.com/hagezi/dns-blocklists/blob/main/LICENSE.md
# Expires: Updated regularly
# Last modified: 19 Apr 2023 08:24 UTC
# Version: 2023.0419.0824.18
# Syntax: Mikrotik rsc import file (including possible subdomains)
# Number of entries: 58
#
/ip/dns/static/add address=127.0.0.1 name=aic-gfts.lge.com
/ip/dns/static/add address=127.0.0.1 name=qt2-ngfts.lge.com
/ip/dns/static/add address=127.0.0.1 name=ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=at.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=be.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=br.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ca.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=cl.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=co.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=de.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=do.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ec.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ee.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=eg.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=gb.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=gr.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=gt.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=hk.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=hn.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=hu.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=id.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=in.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=kz.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=mx.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=my.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=nl.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ph.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=pl.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ro.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=rs.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ru.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=sg.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=th.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=tr.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ua.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=us.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=ve.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=vn.ad.lgsmartad.com
/ip/dns/static/add address=127.0.0.1 name=aic.cdpbeacon.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.cdpbeacon.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.cdpsvc.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=aic.homeprv.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.homeprv.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=kic.homeprv.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=ruc.homeprv.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=aic.nudge.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.nudge.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=kic.nudge.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=ruc.nudge.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=kic.rdl.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=aic.recommend.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.recommend.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=kic.recommend.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=ruc.recommend.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=eic.service.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=kic.service.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=ruc.service.lgtvcommon.com
/ip/dns/static/add address=127.0.0.1 name=aic.wiseconfig.lgtvcommon.com
